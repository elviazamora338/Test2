package com.example.myapplication;

public interface OnMapReadyCallback {
}
