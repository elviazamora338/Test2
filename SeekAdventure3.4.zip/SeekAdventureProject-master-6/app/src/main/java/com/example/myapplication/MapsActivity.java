//package com.example.myapplication;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.fragment.app.FragmentActivity;
//
//import android.Manifest;
//import android.content.pm.PackageManager;
//import android.location.Location;
//import android.os.Bundle;
//import android.widget.FrameLayout;
//
//import com.google.android.gms.maps.CameraUpdateFactory;
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.OnMapReadyCallback;
//import com.google.android.gms.maps.SupportMapFragment;
//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.maps.model.MarkerOptions;
//import com.google.android.gms.tasks.OnSuccessListener;
//import com.google.android.gms.tasks.Task;
//
//
//public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
//
//    Location currentLocation;
//    FusedLocationProviderClient fusedClient;
//    private static final int REQUEST_CODE = 101;
//    FrameLayout map;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_maps);
//
//        map = findViewById(R.id.map);
//
////        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
////        mapFragment.getMapAsync((com.google.android.gms.maps.OnMapReadyCallback) this);
//
//        fusedClient = LocationServices.getFusedLocationProviderClient(this);
//    }
//
//    private void getLocation() {
//        if (ActivityCompat.checkSelfPermission(
//                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
//                && ActivityCompat.checkSelfPermission(
//                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//
//        }
//        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
//        return;
//    }
//
//    Task<Location> task = fusedClient.getLastLocation();
//
//        task.addOnSuccessListener(new OnSuccessListener<Location>(){
//        @Override
//        public void onSuccess (Location location){
//        if (Location != null) {
//            currentLocation = Location;
//            SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
//            assert supportMapFragment != null;
//            supportMapFragment.getMapAsync(MapsActivity.this);
//             }
//         }
//    });
//
//
//
//
//
//
//
//    @Override
//    public void onMapReady(GoogleMap googleMap) {
////        this.gMap = googleMap;
////
////        LatLng mapUnitedStates = new LatLng(37.0902,95.7129);
////        this.gMap.addMarker(new MarkerOptions().position(mapUnitedStates).title("Marker in US"));
////        this.gMap.moveCamera(CameraUpdateFactory.newLatLng(mapUnitedStates));
//
//        LatLng latLg = new LatLng(currentLocation.getLatitude, currentLocation.getLongitude())
//    }
//
//
//}