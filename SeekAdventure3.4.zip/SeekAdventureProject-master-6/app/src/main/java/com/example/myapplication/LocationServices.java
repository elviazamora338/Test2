//package com.example.myapplication;
//
//public class LocationServices {
//    public static FusedLocationProviderClient getFusedLocationProviderClient(MapsActivity mapsActivity) {
//    }
//}
