package com.example.myapplication.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.R;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private static final String TAG = "HomeFragment";
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    private void initImageBitmaps(){
        Log.d(TAG, "intImageBitmaps: perparing bitmaps.");

        mImageUrls.add("dublin.jpg");
        mNames.add("Dublin Ireland");

        mImageUrls.add("maui.jpg");
        mNames.add("Maui, Hawaii ");

        mImageUrls.add("orlando.jpg");
        mNames.add("Orlando, Florida ");

        mImageUrls.add("vancouver.jpg");
        mNames.add("Vancouver, Canada");

        mImageUrls.add("southisland.jpg");
        mNames.add("South Island, New Zealand");

        mNames.add("Dublin Ireland");
        mImageUrls.add("dublin.jpg");


    }
}