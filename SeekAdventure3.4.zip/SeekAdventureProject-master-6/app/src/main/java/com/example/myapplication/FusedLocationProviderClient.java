package com.example.myapplication;

import android.location.Location;

import com.google.android.gms.tasks.Task;

public interface FusedLocationProviderClient {
    Task<Location> getLastLocation();
}
