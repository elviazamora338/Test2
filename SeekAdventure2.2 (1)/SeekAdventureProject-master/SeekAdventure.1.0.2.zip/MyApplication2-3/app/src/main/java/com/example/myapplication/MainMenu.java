package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.app.ActionBar;
import android.widget.Button;
import android.widget.Toolbar;

public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        Button home = findViewById(R.id.home);

        Intent thirdIntent = new Intent(this, HomeFragment.class);

        home.setOnClickListener(v ->
        {
            startActivity(thirdIntent);
        });

    }



}