package com.example.myapplication.MyDestinationView;

public interface DestinationRecyclerViewInterface {
    void onItemClick(int position);

}
